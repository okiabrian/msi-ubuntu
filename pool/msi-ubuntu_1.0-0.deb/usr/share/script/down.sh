#!/bin/bash -e
for file in /usr/share/script/down/*.sh; do sh $file; done
for file in /usr/share/script/down/*1.sh; do sudo rm $file; done
exit
