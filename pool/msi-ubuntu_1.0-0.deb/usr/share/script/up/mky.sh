#!/bin/sh
sudo msiklm blue,green,blue low wave
exit 0
